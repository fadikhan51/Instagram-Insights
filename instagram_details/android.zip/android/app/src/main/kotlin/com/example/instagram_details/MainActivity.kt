package com.example.instagram_details

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
